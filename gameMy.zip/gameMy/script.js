

//run sound
var runSound = new Audio("run.mp3");
runSound.loop = true;

//jump sound
var jumpSound = new Audio("jump.mp3");

//dead sound
var deadSound = new Audio("dead.mp3");

//key event
function keyCheck(event){

    //enter key
    if(event.which == 13){
        if(runWorkerId == 0){

            runWorkerId = setInterval(run, 100);
            runSound.play();

            moveBackgroundWorkId = setInterval(background,100);
            scoreWorkId = setInterval(score,100);
            creatBlockWorkId = setInterval(creatBlock,100);
            moveBlockWorkId = setInterval(moveBlock,100);
        }
       
        

    }

    //space key
    if(event.which == 32){
        if(jumpWorkerId == 0){

            clearInterval(runWorkerId);
            runWorkerId = -1;
            runSound.pause();

            jumpWorkerId = setInterval(jump, 100);
            jumpSound.play();
           
        }


    }
}

//run
var girlId = document.getElementById("girl");
var runImageNumber = 1;
var runWorkerId = 0;

function run(){

    runImageNumber++;

    //run image crash
    if(runImageNumber == 9){
        runImageNumber = 1;
    }
    girlId.src = "Run (" +runImageNumber+ ").png";
   

}

//jump
var jumpImageNumber = 1;
var jumpWorkerId = 0;
var girlMarginTop = 405;

function jump(){
    jumpImageNumber++;

    //jump fly
    if(jumpImageNumber <= 7){
        girlMarginTop = girlMarginTop - 40;
        girlId.style.marginTop = girlMarginTop+"px";
    }

    //jump down
    if(jumpImageNumber >=8){
        girlMarginTop = girlMarginTop + 40;
        girlId.style.marginTop = girlMarginTop+"px";
    }

    //jump image crash
    if(jumpImageNumber == 13){
        jumpImageNumber = 1;

        clearInterval(jumpWorkerId);
        runWorkerId = setInterval(run,100);
        runSound.play();

        jumpWorkerId = 0;

        //starting a jump
        if(scoreWorkId == 0){
            scoreWorkId = setInterval(score,100);
        }
        if(moveBackgroundWorkId == 0){
            moveBackgroundWorkId = setInterval(background,100);
        }
        if(creatBlockWorkId == 0){
            creatBlockWorkId = setInterval(creatBlock,100);
        }
        if(moveBlockWorkId == 0){
            moveBlockWorkId = setInterval(moveBlock,100);
        }
    }

    girlId.src = "Jump (" +jumpImageNumber+ ").png";
}

//background move
var backgroundId = document.getElementById("background");
var positionX = 0;
var moveBackgroundWorkId = 0;

function background(){
    positionX = positionX - 20;
    backgroundId.style.backgroundPositionX = positionX+"px";
}

//score
var scoreId = document.getElementById("score");
var scoreWorkId = 0;
var newScore = 0;

function score(){
    newScore++;
    scoreId.innerHTML = newScore;
}

//create block
var blockMarginLeft = 500;
var creatBlockWorkId = 0;
var blockNumber = 1;

function creatBlock(){

    var block = document.createElement("div");
    block.className = "block";
    block.id = "block" + blockNumber;
    blockNumber++;

    var gap = Math.random()*(1000-400)+400;

    blockMarginLeft = blockMarginLeft + gap;
    block.style.marginLeft = blockMarginLeft + "px";

    document.getElementById("background").appendChild(block);
    
}

//move block
var moveBlockWorkId = 0;

function moveBlock(){

    for(var i=1; i<=blockNumber; i++){

        var currentBlock = document.getElementById("block" + i);
        var currentBlockMarginLeft = currentBlock.style.marginLeft;
        var newBlockMarginLeft = parseInt(currentBlockMarginLeft) - 20;

        currentBlock.style.marginLeft = newBlockMarginLeft + "px";

       // alert(newBlockMarginLeft);
        //151, 31
        //
       if(newBlockMarginLeft < 134 & newBlockMarginLeft > 34){

           // alert(girlMarginTop); //345
            if(girlMarginTop > 345){
                //alert("dead");

                clearInterval(runWorkerId);
                runSound.pause();

                clearInterval(jumpWorkerId);
                jumpWorkerId = -1;

                clearInterval(moveBackgroundWorkId);
                clearInterval(scoreWorkId);
                clearInterval(creatBlockWorkId);
                clearInterval(moveBlockWorkId);

                deadWorkId = setInterval(dead,100);
                deadSound.play();
            }
            
        }

    }
}

//girl dead
var deadImageNumber = 1;
var deadWorkId = 0;

function dead(){
    deadImageNumber++;

    //dead image clash
    if(deadImageNumber == 11){
        deadImageNumber = 10;

        girlId.style.marginTop = "405px";

    
        document.getElementById("endsreen").style.visibility = "visible";
        document.getElementById("endScore").innerHTML = newScore;
    }

    girlId.src = "Dead (" +deadImageNumber+ ").png";

}

//page reload
function reload(){
    location.reload();
}
